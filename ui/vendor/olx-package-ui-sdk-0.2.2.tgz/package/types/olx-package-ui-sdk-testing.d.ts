import { PackageScreenContext, PackageScreenTools, PackageAssets } from '@olx/package-ui-sdk/contract';

type ToolHandler = (input: object) => unknown;
declare function createStubTools(handlers?: Readonly<Record<string, ToolHandler>>): PackageScreenTools;
declare function createPackageContext(overrides?: Partial<PackageScreenContext>): PackageScreenContext;
/**
 * Paths of members that cannot travel over postMessage: anything that is not data, a function or a
 * plain object/array. Reported members are not descended into.
 */
declare function findNonSerializableMembers(value: unknown, path?: string): string[];

/** A `PackageAssets` for tests that also remembers which paths were requested. */
interface StubAssets extends PackageAssets {
    readonly calls: readonly string[];
}
/**
 * Resolves `blob:stub/<path>` for every valid path, or the mapped URL when the path is in `urls`;
 * refuses invalid paths with the error of `assertAssetPath`, like a real Host.
 */
declare function createStubAssets(urls?: Readonly<Record<string, string>>): StubAssets;

export { createPackageContext, createStubAssets, createStubTools, findNonSerializableMembers };
export type { StubAssets, ToolHandler };
//# sourceMappingURL=olx-package-ui-sdk-testing.d.ts.map
