const MAX_ASSET_PATH_LENGTH = 512;
class AssetPathError extends Error {
    constructor(path, reason) {
        super(`Invalid asset path '${path}': ${reason}`);
        this.name = 'AssetPathError';
    }
}
const DRIVE_PREFIX = /^[A-Za-z]:/;
// eslint-disable-next-line no-control-regex -- control characters are exactly what is refused here
const CONTROL_CHARACTER = /[\u0000-\u001f]/;
/** The path rule shared by Screens (fail early) and the Host (which refuses the same inputs). */
function assertAssetPath(path) {
    if (path.trim() === '') {
        throw new AssetPathError(path, 'it is empty');
    }
    if (path.length > MAX_ASSET_PATH_LENGTH) {
        throw new AssetPathError(path, `it is longer than ${String(MAX_ASSET_PATH_LENGTH)} characters`);
    }
    if (path.includes('\\')) {
        throw new AssetPathError(path, 'it contains a backslash');
    }
    if (CONTROL_CHARACTER.test(path)) {
        throw new AssetPathError(path, 'it contains a control character');
    }
    if (path.startsWith('/') || DRIVE_PREFIX.test(path)) {
        throw new AssetPathError(path, 'it is absolute; use a path relative to the package data root');
    }
    if (path.split('/').includes('..')) {
        throw new AssetPathError(path, "it contains a '..' segment");
    }
    return path;
}

class InvalidPackageNameError extends Error {
    packageName;
    constructor(packageName) {
        super(`Invalid package name "${packageName}": use lowercase letters, digits and single hyphens, start with a letter, max 40 characters`);
        this.packageName = packageName;
        this.name = 'InvalidPackageNameError';
    }
}
class InvalidElementTagError extends Error {
    tag;
    requiredPrefix;
    constructor(tag, requiredPrefix) {
        super(`Custom element "${tag}" must start with "${requiredPrefix}" followed by a lowercase name`);
        this.tag = tag;
        this.requiredPrefix = requiredPrefix;
        this.name = 'InvalidElementTagError';
    }
}
const PACKAGE_NAME_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const MAX_PACKAGE_NAME_LENGTH = 40;
const TAG_SUFFIX_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
function elementPrefix(packageName) {
    if (packageName.length === 0 ||
        packageName.length > MAX_PACKAGE_NAME_LENGTH ||
        !PACKAGE_NAME_PATTERN.test(packageName)) {
        throw new InvalidPackageNameError(packageName);
    }
    return `dp-${packageName}-`;
}
function isPackageElementTag(packageName, tag) {
    const prefix = elementPrefix(packageName);
    return tag.startsWith(prefix) && TAG_SUFFIX_PATTERN.test(tag.slice(prefix.length));
}
function assertPackageElementTag(packageName, tag) {
    if (!isPackageElementTag(packageName, tag)) {
        throw new InvalidElementTagError(tag, elementPrefix(packageName));
    }
}

const HOST_UI_API_VERSION = '1';

/**
 * Generated bundle index. Do not edit.
 */

export { AssetPathError, HOST_UI_API_VERSION, InvalidElementTagError, InvalidPackageNameError, MAX_ASSET_PATH_LENGTH, assertAssetPath, assertPackageElementTag, elementPrefix, isPackageElementTag };
//# sourceMappingURL=olx-package-ui-sdk-contract.mjs.map
