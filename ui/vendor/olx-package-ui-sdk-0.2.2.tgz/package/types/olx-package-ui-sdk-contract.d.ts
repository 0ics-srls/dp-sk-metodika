/**
 * Files a package produced (for example a flyer page image) shown by a Screen without a direct URL to the
 * Host API: the Host fetches the file with the Operator's credentials and hands back a `blob:` URL.
 * Additive member of contract v0.4; `hostUiApi` stays `'1'`.
 */
interface PackageAssets {
    /**
     * Resolves a path relative to the package data root (for example `flyers/abc/raw/p001.png`) to a
     * `blob:` URL that is valid until the element is destroyed.
     */
    url(path: string): Promise<string>;
}
declare const MAX_ASSET_PATH_LENGTH = 512;
declare class AssetPathError extends Error {
    constructor(path: string, reason: string);
}
/** The path rule shared by Screens (fail early) and the Host (which refuses the same inputs). */
declare function assertAssetPath(path: string): string;

declare class InvalidPackageNameError extends Error {
    readonly packageName: string;
    constructor(packageName: string);
}
declare class InvalidElementTagError extends Error {
    readonly tag: string;
    readonly requiredPrefix: string;
    constructor(tag: string, requiredPrefix: string);
}
declare function elementPrefix(packageName: string): string;
declare function isPackageElementTag(packageName: string, tag: string): boolean;
declare function assertPackageElementTag(packageName: string, tag: string): void;

type HostUiApiVersion = '1';
type PackageLocale = 'sk' | 'en' | 'it';
type PackageTheme = 'light' | 'dark';
type NotifyLevel = 'success' | 'info' | 'warn' | 'error';
type QueryParams = Readonly<Record<string, string>>;
interface PackageScreenTools {
    call<T>(tool: string, input?: object): Promise<T>;
}
/** What the host hands to a package screen. Rebuilt as a NEW object on every change, never mutated. */
interface PackageScreenContext {
    readonly hostUiApi: HostUiApiVersion;
    readonly package: {
        readonly name: string;
        readonly version: string;
    };
    readonly screen: string;
    readonly subPath: string;
    readonly query: QueryParams;
    readonly locale: PackageLocale;
    readonly theme: PackageTheme;
    readonly user: {
        readonly name: string;
        readonly roles: readonly string[];
    };
    readonly cspNonce: string;
    readonly source?: {
        readonly id: string;
        readonly sourceType: string;
    };
    readonly tools: PackageScreenTools;
    /** Files of the package (v0.4, additive): `blob:` URLs fetched by the Host with the Operator's credentials. */
    readonly assets: PackageAssets;
    navigate(subPath: string, query?: QueryParams): void;
    navigateScreen(screen: string, subPath?: string): void;
    setTitle(title: string): void;
    notify(level: NotifyLevel, message: string): void;
    confirm(message: string): Promise<boolean>;
    refreshBadges(): void;
}

interface LocalizedText {
    readonly sk: string;
    readonly en: string;
    readonly it?: string;
}
interface PackageScreenDescriptor {
    readonly id: string;
    readonly element: string;
    readonly label: LocalizedText;
    readonly icon?: string;
    readonly default?: boolean;
}
interface PackageMenuDescriptor {
    readonly label: LocalizedText;
    readonly icon: string;
    readonly order: number;
}
/** Registry response element: the `ui` section of the Manifest plus name and version. */
interface PackageUiDescriptor {
    readonly name: string;
    readonly version: string;
    readonly hostUiApi: HostUiApiVersion;
    readonly entry: string;
    readonly styles: readonly string[];
    readonly menu: PackageMenuDescriptor;
    readonly screens: readonly PackageScreenDescriptor[];
}

declare const HOST_UI_API_VERSION: "1";

export { AssetPathError, HOST_UI_API_VERSION, InvalidElementTagError, InvalidPackageNameError, MAX_ASSET_PATH_LENGTH, assertAssetPath, assertPackageElementTag, elementPrefix, isPackageElementTag };
export type { HostUiApiVersion, LocalizedText, NotifyLevel, PackageAssets, PackageLocale, PackageMenuDescriptor, PackageScreenContext, PackageScreenDescriptor, PackageScreenTools, PackageTheme, PackageUiDescriptor, QueryParams };
//# sourceMappingURL=olx-package-ui-sdk-contract.d.ts.map
